import os

# Local-test value so handler.py can initialize the SNS configuration.
os.environ["SNS_TOPIC_ARN"] = (
    "arn:aws:sns:us-east-1:000000000000:test-remediation-topic"
)

import lambda_functions.handler as handler


class FakeSNS:
    """Fake SNS client used for local testing."""

    def publish(self, **kwargs):
        print("\n========== SNS PUBLISH ==========")
        print("TopicArn:", kwargs["TopicArn"])
        print("Subject:", kwargs["Subject"])
        print("Message:")
        print(kwargs["Message"])
        print("=================================\n")

        return {
            "MessageId": "local-test-message-id"
        }


class FakeEC2:
    """Fake EC2 client used for safe local remediation testing."""

    class Meta:
        region_name = "us-east-1"

    meta = Meta()

    def revoke_security_group_ingress(self, **kwargs):
        print("\n========== EC2 REVOKE ==========")
        print("GroupId:", kwargs["GroupId"])
        print("IpPermissions:", kwargs["IpPermissions"])
        print("================================\n")

        return {}


# Replace the real SNS client with our fake client.
handler.sns_client = FakeSNS()


event = {
    "source": "aws.ec2",
    "detail-type": "AWS API Call via CloudTrail",
    "detail": {
        "eventSource": "ec2.amazonaws.com",
        "eventName": "AuthorizeSecurityGroupIngress",
        "awsRegion": "us-east-1",
        "eventTime": "2026-09-10T21:26:39Z",
        "userIdentity": {
            "type": "IAMUser",
            "principalId": "AIDAU6GDVNJCOR3VWUC52",
            "arn": "arn:aws:iam::339712764484:user/terraform-deploy",
            "accountId": "339712764484",
            "accessKeyId": "AKIAU6GDVNJCJXXXXXXX",
            "userName": "terraform-deploy",
        },
        "requestParameters": {
            "groupId": "sg-0eea745ba19b92168",
        },
    },
}


# Keep the real collector/check so we verify the actual
# security-group detection logic against AWS.
#
# Only the EC2 remediation method is replaced.
original_ec2_client = handler.boto3.client


def fake_boto3_client(service_name, *args, **kwargs):
    if service_name == "ec2":
        real_client = original_ec2_client(
            service_name,
            *args,
            **kwargs,
        )

        # We still need the real client for collection/checking.
        # The remediation method will be replaced below.
        original_revoke = real_client.revoke_security_group_ingress

        def fake_revoke_security_group_ingress(**revoke_kwargs):
            return FakeEC2().revoke_security_group_ingress(
                **revoke_kwargs
            )

        real_client.revoke_security_group_ingress = (
            fake_revoke_security_group_ingress
        )

        return real_client

    return original_ec2_client(
        service_name,
        *args,
        **kwargs,
    )


handler.boto3.client = fake_boto3_client


result = handler.lambda_handler(event, None)


print("\n========== LAMBDA RESULT ==========")
print(result)
print("====================================")